﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.picPreview = new System.Windows.Forms.PictureBox();
            this.trkzoom = new System.Windows.Forms.TrackBar();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabEditor = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.chkFixedSize = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSpriteSettings = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.chkAligned = new System.Windows.Forms.CheckBox();
            this.btnNextBank = new System.Windows.Forms.Button();
            this.btnLastBank = new System.Windows.Forms.Button();
            this.lblBackupTaken = new System.Windows.Forms.Label();
            this.btnNextSprite = new System.Windows.Forms.Button();
            this.btnLastSprite = new System.Windows.Forms.Button();
            this.btnRedo = new System.Windows.Forms.Button();
            this.btnUndo = new System.Windows.Forms.Button();
            this.btnColorSwap = new System.Windows.Forms.Button();
            this.btnChecker = new System.Windows.Forms.Button();
            this.btnZXpaint = new System.Windows.Forms.Button();
            this.lblSpriteInfo = new System.Windows.Forms.Label();
            this.btnSetPal = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.grpSpriteSize = new System.Windows.Forms.GroupBox();
            this.rdospr512 = new System.Windows.Forms.RadioButton();
            this.rdospr256 = new System.Windows.Forms.RadioButton();
            this.GrpFrameOverlay = new System.Windows.Forms.GroupBox();
            this.rdoFrameLast = new System.Windows.Forms.RadioButton();
            this.rdoFrameNext = new System.Windows.Forms.RadioButton();
            this.rdoFrameNone = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.chkHasDosHeader = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rdoDisplayCPC0 = new System.Windows.Forms.RadioButton();
            this.ChkBackgroundTestDots = new System.Windows.Forms.CheckBox();
            this.chkStrongGrid = new System.Windows.Forms.CheckBox();
            this.rdoDisplaySpeccy = new System.Windows.Forms.RadioButton();
            this.rdoDisplayCPC = new System.Windows.Forms.RadioButton();
            this.rdoDisplayMSX = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoGuide4_8_32 = new System.Windows.Forms.RadioButton();
            this.rdoGuide4_8_24 = new System.Windows.Forms.RadioButton();
            this.rdoGuideNone = new System.Windows.Forms.RadioButton();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lblMaxSpritesByOffset = new System.Windows.Forms.Label();
            this.txtSpriteDataOffSet = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lstSprites = new System.Windows.Forms.ListBox();
            this.tmrBackup = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.reSaveSpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.savePaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToClipboardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToClipToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.canvasSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duplicateFromToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.duplicateOffsetFromToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.makeTilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mSX16ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cPC4ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zX2ColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highVisToggleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overlayLastFrameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overlayNextFrameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transformToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flipXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.flipYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pxShiftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pixelShiftRightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pixelShiftUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pixelShiftDownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileShiftXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colorSwapAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yInterlaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setAllAttribsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blackBorderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blackBorderTightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PaletteTint = new System.Windows.Forms.ToolStripMenuItem();
            this.cPCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.loadCPCBinaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCPCBinaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.loadCPCBinaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCPCBinaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveCPCRawBmp = new System.Windows.Forms.ToolStripMenuItem();
            this.rLEASMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveCPCZigTileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spriteCompilerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addOneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveASMPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mSXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXASMPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXBinaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bMPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXBitmapToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXBitmapWithPaletteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXBitmapSpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rLEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buildRLEASMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXRLEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXRLEPaletteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveMSXRLESpritesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRAWBitmapToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.zXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadSpectrumScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpectrumBinaryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpectrumTilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpectrumFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveSpectrumScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.rLEASMToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.rLEASMCOLORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fourColor2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.invertZXToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.halfSizeFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spriteCompilerToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.addOneToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteZXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.filrToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sAMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRLEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eNTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRAWBitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sMSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.gBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveRawBitmapToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.picPreview)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkzoom)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabEditor.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.grpSpriteSize.SuspendLayout();
            this.GrpFrameOverlay.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoScroll = true;
            this.panel1.Location = new System.Drawing.Point(48, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(694, 524);
            this.panel1.TabIndex = 0;
            // 
            // picPreview
            // 
            this.picPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picPreview.BackColor = System.Drawing.Color.Black;
            this.picPreview.Location = new System.Drawing.Point(752, 64);
            this.picPreview.Name = "picPreview";
            this.picPreview.Size = new System.Drawing.Size(256, 236);
            this.picPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picPreview.TabIndex = 1;
            this.picPreview.TabStop = false;
            // 
            // trkzoom
            // 
            this.trkzoom.Location = new System.Drawing.Point(0, 48);
            this.trkzoom.Maximum = 32;
            this.trkzoom.Minimum = 2;
            this.trkzoom.Name = "trkzoom";
            this.trkzoom.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trkzoom.Size = new System.Drawing.Size(42, 153);
            this.trkzoom.TabIndex = 2;
            this.trkzoom.TickFrequency = 2;
            this.trkzoom.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trkzoom.Value = 4;
            this.trkzoom.Scroll += new System.EventHandler(this.trkzoom_Scroll);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabEditor);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(4, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1024, 608);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tabControl1_KeyDown);
            // 
            // tabEditor
            // 
            this.tabEditor.Controls.Add(this.groupBox3);
            this.tabEditor.Controls.Add(this.btnNextBank);
            this.tabEditor.Controls.Add(this.btnLastBank);
            this.tabEditor.Controls.Add(this.lblBackupTaken);
            this.tabEditor.Controls.Add(this.btnNextSprite);
            this.tabEditor.Controls.Add(this.btnLastSprite);
            this.tabEditor.Controls.Add(this.btnRedo);
            this.tabEditor.Controls.Add(this.btnUndo);
            this.tabEditor.Controls.Add(this.btnColorSwap);
            this.tabEditor.Controls.Add(this.btnChecker);
            this.tabEditor.Controls.Add(this.btnZXpaint);
            this.tabEditor.Controls.Add(this.lblSpriteInfo);
            this.tabEditor.Controls.Add(this.btnSetPal);
            this.tabEditor.Controls.Add(this.btnRefresh);
            this.tabEditor.Controls.Add(this.trkzoom);
            this.tabEditor.Controls.Add(this.panel1);
            this.tabEditor.Controls.Add(this.picPreview);
            this.tabEditor.Location = new System.Drawing.Point(4, 21);
            this.tabEditor.Name = "tabEditor";
            this.tabEditor.Padding = new System.Windows.Forms.Padding(3);
            this.tabEditor.Size = new System.Drawing.Size(1016, 583);
            this.tabEditor.TabIndex = 0;
            this.tabEditor.Text = "Editor";
            this.tabEditor.UseVisualStyleBackColor = true;
            this.tabEditor.Click += new System.EventHandler(this.tabEditor_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.chkFixedSize);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.txtSpriteSettings);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.chkAligned);
            this.groupBox3.Location = new System.Drawing.Point(753, 332);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(256, 158);
            this.groupBox3.TabIndex = 18;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sprite Attribs";
            // 
            // chkFixedSize
            // 
            this.chkFixedSize.AutoSize = true;
            this.chkFixedSize.Location = new System.Drawing.Point(59, 136);
            this.chkFixedSize.Name = "chkFixedSize";
            this.chkFixedSize.Size = new System.Drawing.Size(73, 16);
            this.chkFixedSize.TabIndex = 4;
            this.chkFixedSize.Text = "FixedSize";
            this.chkFixedSize.UseVisualStyleBackColor = true;
            this.chkFixedSize.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chkFixedSize_MouseUp);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(59, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 52);
            this.label3.TabIndex = 3;
            this.label3.Text = "+128 = PSET\r\n+64 = DblHeight / nocolorZX\r\n+32 = SpeccyTransp\r\n+4/5 = CPC transp\r\n" +
                "";
            // 
            // txtSpriteSettings
            // 
            this.txtSpriteSettings.Location = new System.Drawing.Point(59, 43);
            this.txtSpriteSettings.Name = "txtSpriteSettings";
            this.txtSpriteSettings.Size = new System.Drawing.Size(92, 19);
            this.txtSpriteSettings.TabIndex = 2;
            this.txtSpriteSettings.TextChanged += new System.EventHandler(this.txtSpriteSettings_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "Settings";
            // 
            // chkAligned
            // 
            this.chkAligned.AutoSize = true;
            this.chkAligned.Location = new System.Drawing.Point(62, 22);
            this.chkAligned.Name = "chkAligned";
            this.chkAligned.Size = new System.Drawing.Size(90, 16);
            this.chkAligned.TabIndex = 0;
            this.chkAligned.Text = "Byte Aligned";
            this.chkAligned.UseVisualStyleBackColor = true;
            this.chkAligned.CheckedChanged += new System.EventHandler(this.chkAligned_CheckedChanged);
            // 
            // btnNextBank
            // 
            this.btnNextBank.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNextBank.Location = new System.Drawing.Point(804, 498);
            this.btnNextBank.Name = "btnNextBank";
            this.btnNextBank.Size = new System.Drawing.Size(46, 37);
            this.btnNextBank.TabIndex = 17;
            this.btnNextBank.Text = "Next Bank";
            this.toolTip1.SetToolTip(this.btnNextBank, "Last Bank (Cursor Up)");
            this.btnNextBank.UseVisualStyleBackColor = true;
            this.btnNextBank.Click += new System.EventHandler(this.btnNextBank_Click);
            // 
            // btnLastBank
            // 
            this.btnLastBank.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLastBank.Location = new System.Drawing.Point(752, 498);
            this.btnLastBank.Name = "btnLastBank";
            this.btnLastBank.Size = new System.Drawing.Size(46, 37);
            this.btnLastBank.TabIndex = 16;
            this.btnLastBank.Text = "Last Bank";
            this.toolTip1.SetToolTip(this.btnLastBank, "Last Bank (Cursor Down)");
            this.btnLastBank.UseVisualStyleBackColor = true;
            this.btnLastBank.Click += new System.EventHandler(this.btnLastBank_Click);
            // 
            // lblBackupTaken
            // 
            this.lblBackupTaken.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.lblBackupTaken.AutoSize = true;
            this.lblBackupTaken.Location = new System.Drawing.Point(958, 527);
            this.lblBackupTaken.Name = "lblBackupTaken";
            this.lblBackupTaken.Size = new System.Drawing.Size(8, 12);
            this.lblBackupTaken.TabIndex = 15;
            this.lblBackupTaken.Text = "!";
            // 
            // btnNextSprite
            // 
            this.btnNextSprite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNextSprite.Location = new System.Drawing.Point(804, 534);
            this.btnNextSprite.Name = "btnNextSprite";
            this.btnNextSprite.Size = new System.Drawing.Size(46, 37);
            this.btnNextSprite.TabIndex = 14;
            this.btnNextSprite.Text = "Next Sprite";
            this.toolTip1.SetToolTip(this.btnNextSprite, "Next Sprite (Cursor Right)");
            this.btnNextSprite.UseVisualStyleBackColor = true;
            this.btnNextSprite.Click += new System.EventHandler(this.btnNextSprite_Click);
            // 
            // btnLastSprite
            // 
            this.btnLastSprite.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLastSprite.Location = new System.Drawing.Point(752, 535);
            this.btnLastSprite.Name = "btnLastSprite";
            this.btnLastSprite.Size = new System.Drawing.Size(46, 37);
            this.btnLastSprite.TabIndex = 13;
            this.btnLastSprite.Text = "Last Sprite";
            this.toolTip1.SetToolTip(this.btnLastSprite, "Last Sprite (Cursor Left)");
            this.btnLastSprite.UseVisualStyleBackColor = true;
            this.btnLastSprite.Click += new System.EventHandler(this.btnLastSprite_Click);
            // 
            // btnRedo
            // 
            this.btnRedo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRedo.Location = new System.Drawing.Point(967, 521);
            this.btnRedo.Name = "btnRedo";
            this.btnRedo.Size = new System.Drawing.Size(46, 23);
            this.btnRedo.TabIndex = 12;
            this.btnRedo.Text = "Redo";
            this.toolTip1.SetToolTip(this.btnRedo, "Redo (Ctrl-Shift-Z)");
            this.btnRedo.UseVisualStyleBackColor = true;
            this.btnRedo.Click += new System.EventHandler(this.btnRedo_Click);
            // 
            // btnUndo
            // 
            this.btnUndo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUndo.Location = new System.Drawing.Point(907, 521);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(49, 23);
            this.btnUndo.TabIndex = 11;
            this.btnUndo.Text = "Undo";
            this.toolTip1.SetToolTip(this.btnUndo, "Undo (Ctrl-Z)");
            this.btnUndo.UseVisualStyleBackColor = true;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            // 
            // btnColorSwap
            // 
            this.btnColorSwap.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnColorSwap.Location = new System.Drawing.Point(856, 550);
            this.btnColorSwap.Name = "btnColorSwap";
            this.btnColorSwap.Size = new System.Drawing.Size(155, 22);
            this.btnColorSwap.TabIndex = 10;
            this.btnColorSwap.Text = "Color Swap";
            this.btnColorSwap.UseVisualStyleBackColor = true;
            this.btnColorSwap.Click += new System.EventHandler(this.btnColorSwap_Click);
            // 
            // btnChecker
            // 
            this.btnChecker.Location = new System.Drawing.Point(0, 278);
            this.btnChecker.Name = "btnChecker";
            this.btnChecker.Size = new System.Drawing.Size(48, 22);
            this.btnChecker.TabIndex = 9;
            this.btnChecker.Text = "ck 0";
            this.toolTip1.SetToolTip(this.btnChecker, "Checker Pattern effect");
            this.btnChecker.UseVisualStyleBackColor = true;
            this.btnChecker.Click += new System.EventHandler(this.btnChecker_Click);
            // 
            // btnZXpaint
            // 
            this.btnZXpaint.Location = new System.Drawing.Point(0, 251);
            this.btnZXpaint.Name = "btnZXpaint";
            this.btnZXpaint.Size = new System.Drawing.Size(48, 22);
            this.btnZXpaint.TabIndex = 6;
            this.btnZXpaint.Text = "zx N";
            this.btnZXpaint.UseVisualStyleBackColor = true;
            this.btnZXpaint.Click += new System.EventHandler(this.btnZXpaint_Click);
            // 
            // lblSpriteInfo
            // 
            this.lblSpriteInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSpriteInfo.AutoSize = true;
            this.lblSpriteInfo.Location = new System.Drawing.Point(753, 304);
            this.lblSpriteInfo.Name = "lblSpriteInfo";
            this.lblSpriteInfo.Size = new System.Drawing.Size(7, 12);
            this.lblSpriteInfo.TabIndex = 5;
            this.lblSpriteInfo.Text = ".";
            // 
            // btnSetPal
            // 
            this.btnSetPal.Location = new System.Drawing.Point(-4, 225);
            this.btnSetPal.Name = "btnSetPal";
            this.btnSetPal.Size = new System.Drawing.Size(52, 26);
            this.btnSetPal.TabIndex = 4;
            this.btnSetPal.Text = "SetPal";
            this.btnSetPal.UseVisualStyleBackColor = true;
            this.btnSetPal.Click += new System.EventHandler(this.btnSetPal_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(-4, 201);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(52, 26);
            this.btnRefresh.TabIndex = 3;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.grpSpriteSize);
            this.tabPage2.Controls.Add(this.GrpFrameOverlay);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.groupBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1016, 583);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Settings";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // grpSpriteSize
            // 
            this.grpSpriteSize.Controls.Add(this.rdospr512);
            this.grpSpriteSize.Controls.Add(this.rdospr256);
            this.grpSpriteSize.Location = new System.Drawing.Point(239, 67);
            this.grpSpriteSize.Name = "grpSpriteSize";
            this.grpSpriteSize.Size = new System.Drawing.Size(171, 63);
            this.grpSpriteSize.TabIndex = 15;
            this.grpSpriteSize.TabStop = false;
            this.grpSpriteSize.Text = "MAX SpriteSize";
            // 
            // rdospr512
            // 
            this.rdospr512.AutoSize = true;
            this.rdospr512.Location = new System.Drawing.Point(7, 35);
            this.rdospr512.Name = "rdospr512";
            this.rdospr512.Size = new System.Drawing.Size(65, 16);
            this.rdospr512.TabIndex = 1;
            this.rdospr512.Text = "512x512";
            this.rdospr512.UseVisualStyleBackColor = true;
            this.rdospr512.CheckedChanged += new System.EventHandler(this.rdospr512_CheckedChanged);
            // 
            // rdospr256
            // 
            this.rdospr256.AutoSize = true;
            this.rdospr256.Checked = true;
            this.rdospr256.Location = new System.Drawing.Point(6, 18);
            this.rdospr256.Name = "rdospr256";
            this.rdospr256.Size = new System.Drawing.Size(65, 16);
            this.rdospr256.TabIndex = 0;
            this.rdospr256.TabStop = true;
            this.rdospr256.Text = "256x256";
            this.rdospr256.UseVisualStyleBackColor = true;
            this.rdospr256.CheckedChanged += new System.EventHandler(this.rdospr256_CheckedChanged);
            // 
            // GrpFrameOverlay
            // 
            this.GrpFrameOverlay.Controls.Add(this.rdoFrameLast);
            this.GrpFrameOverlay.Controls.Add(this.rdoFrameNext);
            this.GrpFrameOverlay.Controls.Add(this.rdoFrameNone);
            this.GrpFrameOverlay.Location = new System.Drawing.Point(239, 136);
            this.GrpFrameOverlay.Name = "GrpFrameOverlay";
            this.GrpFrameOverlay.Size = new System.Drawing.Size(144, 88);
            this.GrpFrameOverlay.TabIndex = 14;
            this.GrpFrameOverlay.TabStop = false;
            this.GrpFrameOverlay.Text = "FrameOverlay";
            // 
            // rdoFrameLast
            // 
            this.rdoFrameLast.AutoSize = true;
            this.rdoFrameLast.Location = new System.Drawing.Point(8, 62);
            this.rdoFrameLast.Name = "rdoFrameLast";
            this.rdoFrameLast.Size = new System.Drawing.Size(45, 16);
            this.rdoFrameLast.TabIndex = 16;
            this.rdoFrameLast.Text = "Last";
            this.rdoFrameLast.UseVisualStyleBackColor = true;
            this.rdoFrameLast.CheckedChanged += new System.EventHandler(this.rdoFrameLast_CheckedChanged);
            // 
            // rdoFrameNext
            // 
            this.rdoFrameNext.AutoSize = true;
            this.rdoFrameNext.Location = new System.Drawing.Point(8, 40);
            this.rdoFrameNext.Name = "rdoFrameNext";
            this.rdoFrameNext.Size = new System.Drawing.Size(47, 16);
            this.rdoFrameNext.TabIndex = 15;
            this.rdoFrameNext.Text = "Next";
            this.rdoFrameNext.UseVisualStyleBackColor = true;
            this.rdoFrameNext.CheckedChanged += new System.EventHandler(this.rdoFrameNext_CheckedChanged);
            // 
            // rdoFrameNone
            // 
            this.rdoFrameNone.AutoSize = true;
            this.rdoFrameNone.Checked = true;
            this.rdoFrameNone.Location = new System.Drawing.Point(9, 18);
            this.rdoFrameNone.Name = "rdoFrameNone";
            this.rdoFrameNone.Size = new System.Drawing.Size(49, 16);
            this.rdoFrameNone.TabIndex = 15;
            this.rdoFrameNone.TabStop = true;
            this.rdoFrameNone.Text = "None";
            this.rdoFrameNone.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.chkHasDosHeader);
            this.groupBox4.Location = new System.Drawing.Point(238, 11);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(173, 50);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Binary Files";
            // 
            // chkHasDosHeader
            // 
            this.chkHasDosHeader.AutoSize = true;
            this.chkHasDosHeader.Checked = true;
            this.chkHasDosHeader.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkHasDosHeader.Location = new System.Drawing.Point(6, 18);
            this.chkHasDosHeader.Name = "chkHasDosHeader";
            this.chkHasDosHeader.Size = new System.Drawing.Size(100, 16);
            this.chkHasDosHeader.TabIndex = 6;
            this.chkHasDosHeader.Text = "HasDosHeader";
            this.toolTip1.SetToolTip(this.chkHasDosHeader, "File has a header");
            this.chkHasDosHeader.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rdoDisplayCPC0);
            this.groupBox2.Controls.Add(this.ChkBackgroundTestDots);
            this.groupBox2.Controls.Add(this.chkStrongGrid);
            this.groupBox2.Controls.Add(this.rdoDisplaySpeccy);
            this.groupBox2.Controls.Add(this.rdoDisplayCPC);
            this.groupBox2.Controls.Add(this.rdoDisplayMSX);
            this.groupBox2.Location = new System.Drawing.Point(88, 11);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(144, 213);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "DisplayMode";
            // 
            // rdoDisplayCPC0
            // 
            this.rdoDisplayCPC0.AutoSize = true;
            this.rdoDisplayCPC0.Location = new System.Drawing.Point(8, 55);
            this.rdoDisplayCPC0.Name = "rdoDisplayCPC0";
            this.rdoDisplayCPC0.Size = new System.Drawing.Size(115, 16);
            this.rdoDisplayCPC0.TabIndex = 16;
            this.rdoDisplayCPC0.Text = "CPC/ENT Mode 0";
            this.toolTip1.SetToolTip(this.rdoDisplayCPC0, "4 color");
            this.rdoDisplayCPC0.UseVisualStyleBackColor = true;
            // 
            // ChkBackgroundTestDots
            // 
            this.ChkBackgroundTestDots.AutoSize = true;
            this.ChkBackgroundTestDots.Location = new System.Drawing.Point(6, 187);
            this.ChkBackgroundTestDots.Name = "ChkBackgroundTestDots";
            this.ChkBackgroundTestDots.Size = new System.Drawing.Size(139, 16);
            this.ChkBackgroundTestDots.TabIndex = 15;
            this.ChkBackgroundTestDots.Text = "Background Test Dots";
            this.toolTip1.SetToolTip(this.ChkBackgroundTestDots, "Make the Grid more visible");
            this.ChkBackgroundTestDots.UseVisualStyleBackColor = true;
            // 
            // chkStrongGrid
            // 
            this.chkStrongGrid.AutoSize = true;
            this.chkStrongGrid.Checked = true;
            this.chkStrongGrid.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkStrongGrid.Location = new System.Drawing.Point(6, 165);
            this.chkStrongGrid.Name = "chkStrongGrid";
            this.chkStrongGrid.Size = new System.Drawing.Size(121, 16);
            this.chkStrongGrid.TabIndex = 14;
            this.chkStrongGrid.Text = "High Visibility Grid";
            this.toolTip1.SetToolTip(this.chkStrongGrid, "Make the Grid more visible");
            this.chkStrongGrid.UseVisualStyleBackColor = true;
            this.chkStrongGrid.CheckedChanged += new System.EventHandler(this.chkStrongGrid_CheckedChanged);
            // 
            // rdoDisplaySpeccy
            // 
            this.rdoDisplaySpeccy.AutoSize = true;
            this.rdoDisplaySpeccy.Location = new System.Drawing.Point(8, 77);
            this.rdoDisplaySpeccy.Name = "rdoDisplaySpeccy";
            this.rdoDisplaySpeccy.Size = new System.Drawing.Size(105, 16);
            this.rdoDisplaySpeccy.TabIndex = 6;
            this.rdoDisplaySpeccy.Text = "Spectrum/TI-83";
            this.toolTip1.SetToolTip(this.rdoDisplaySpeccy, "Spectrum screen - Anything not Color 1 is on");
            this.rdoDisplaySpeccy.UseVisualStyleBackColor = true;
            this.rdoDisplaySpeccy.CheckedChanged += new System.EventHandler(this.rdoDisplaySpeccy_CheckedChanged);
            // 
            // rdoDisplayCPC
            // 
            this.rdoDisplayCPC.AutoSize = true;
            this.rdoDisplayCPC.Location = new System.Drawing.Point(8, 33);
            this.rdoDisplayCPC.Name = "rdoDisplayCPC";
            this.rdoDisplayCPC.Size = new System.Drawing.Size(115, 16);
            this.rdoDisplayCPC.TabIndex = 5;
            this.rdoDisplayCPC.Text = "CPC/ENT Mode 1";
            this.toolTip1.SetToolTip(this.rdoDisplayCPC, "4 color");
            this.rdoDisplayCPC.UseVisualStyleBackColor = true;
            this.rdoDisplayCPC.CheckedChanged += new System.EventHandler(this.rdoDisplayCPC_CheckedChanged);
            // 
            // rdoDisplayMSX
            // 
            this.rdoDisplayMSX.AutoSize = true;
            this.rdoDisplayMSX.Checked = true;
            this.rdoDisplayMSX.Location = new System.Drawing.Point(8, 15);
            this.rdoDisplayMSX.Name = "rdoDisplayMSX";
            this.rdoDisplayMSX.Size = new System.Drawing.Size(127, 16);
            this.rdoDisplayMSX.TabIndex = 4;
            this.rdoDisplayMSX.TabStop = true;
            this.rdoDisplayMSX.Text = "MSX / SAM / CPC+";
            this.toolTip1.SetToolTip(this.rdoDisplayMSX, "16 color");
            this.rdoDisplayMSX.UseVisualStyleBackColor = true;
            this.rdoDisplayMSX.CheckedChanged += new System.EventHandler(this.rdoDisplayMSX_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoGuide4_8_32);
            this.groupBox1.Controls.Add(this.rdoGuide4_8_24);
            this.groupBox1.Controls.Add(this.rdoGuideNone);
            this.groupBox1.Location = new System.Drawing.Point(4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(80, 126);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Guides";
            // 
            // rdoGuide4_8_32
            // 
            this.rdoGuide4_8_32.AutoSize = true;
            this.rdoGuide4_8_32.Location = new System.Drawing.Point(4, 52);
            this.rdoGuide4_8_32.Name = "rdoGuide4_8_32";
            this.rdoGuide4_8_32.Size = new System.Drawing.Size(51, 16);
            this.rdoGuide4_8_32.TabIndex = 4;
            this.rdoGuide4_8_32.Text = "4,8,32";
            this.rdoGuide4_8_32.UseVisualStyleBackColor = true;
            // 
            // rdoGuide4_8_24
            // 
            this.rdoGuide4_8_24.AutoSize = true;
            this.rdoGuide4_8_24.Checked = true;
            this.rdoGuide4_8_24.Location = new System.Drawing.Point(4, 33);
            this.rdoGuide4_8_24.Name = "rdoGuide4_8_24";
            this.rdoGuide4_8_24.Size = new System.Drawing.Size(51, 16);
            this.rdoGuide4_8_24.TabIndex = 3;
            this.rdoGuide4_8_24.TabStop = true;
            this.rdoGuide4_8_24.Text = "4,8,24";
            this.rdoGuide4_8_24.UseVisualStyleBackColor = true;
            // 
            // rdoGuideNone
            // 
            this.rdoGuideNone.AutoSize = true;
            this.rdoGuideNone.Location = new System.Drawing.Point(4, 15);
            this.rdoGuideNone.Name = "rdoGuideNone";
            this.rdoGuideNone.Size = new System.Drawing.Size(49, 16);
            this.rdoGuideNone.TabIndex = 2;
            this.rdoGuideNone.Text = "None";
            this.rdoGuideNone.UseVisualStyleBackColor = true;
            this.rdoGuideNone.CheckedChanged += new System.EventHandler(this.rdoGuideNone_CheckedChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lblMaxSpritesByOffset);
            this.tabPage1.Controls.Add(this.txtSpriteDataOffSet);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.lstSprites);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1016, 583);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "SpriteList";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblMaxSpritesByOffset
            // 
            this.lblMaxSpritesByOffset.AutoSize = true;
            this.lblMaxSpritesByOffset.Location = new System.Drawing.Point(635, 11);
            this.lblMaxSpritesByOffset.Name = "lblMaxSpritesByOffset";
            this.lblMaxSpritesByOffset.Size = new System.Drawing.Size(7, 12);
            this.lblMaxSpritesByOffset.TabIndex = 3;
            this.lblMaxSpritesByOffset.Text = ".";
            // 
            // txtSpriteDataOffSet
            // 
            this.txtSpriteDataOffSet.Location = new System.Drawing.Point(512, 8);
            this.txtSpriteDataOffSet.Name = "txtSpriteDataOffSet";
            this.txtSpriteDataOffSet.Size = new System.Drawing.Size(108, 19);
            this.txtSpriteDataOffSet.TabIndex = 2;
            this.txtSpriteDataOffSet.Text = "&180";
            this.toolTip1.SetToolTip(this.txtSpriteDataOffSet, "Memory offset of first sprite in binary files");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(413, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "SpriteDataOffSet";
            // 
            // lstSprites
            // 
            this.lstSprites.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstSprites.FormattingEnabled = true;
            this.lstSprites.ItemHeight = 14;
            this.lstSprites.Location = new System.Drawing.Point(4, 4);
            this.lstSprites.Name = "lstSprites";
            this.lstSprites.Size = new System.Drawing.Size(404, 368);
            this.lstSprites.TabIndex = 0;
            this.lstSprites.SelectedIndexChanged += new System.EventHandler(this.lstSprites_SelectedIndexChanged);
            // 
            // tmrBackup
            // 
            this.tmrBackup.Tick += new System.EventHandler(this.tmrBackup_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem2,
            this.editToolStripMenuItem,
            this.ViewToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.cPCToolStripMenuItem,
            this.mSXToolStripMenuItem,
            this.zXToolStripMenuItem,
            this.tIToolStripMenuItem,
            this.sAMToolStripMenuItem,
            this.eNTToolStripMenuItem,
            this.sMSToolStripMenuItem,
            this.gBToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1031, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem2
            // 
            this.fileToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reSaveSpritesToolStripMenuItem,
            this.saveSpritesToolStripMenuItem,
            this.savePaletteToolStripMenuItem,
            this.loadToolStripMenuItem});
            this.fileToolStripMenuItem2.Name = "fileToolStripMenuItem2";
            this.fileToolStripMenuItem2.Size = new System.Drawing.Size(36, 20);
            this.fileToolStripMenuItem2.Text = "File";
            // 
            // reSaveSpritesToolStripMenuItem
            // 
            this.reSaveSpritesToolStripMenuItem.Enabled = false;
            this.reSaveSpritesToolStripMenuItem.Name = "reSaveSpritesToolStripMenuItem";
            this.reSaveSpritesToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.reSaveSpritesToolStripMenuItem.Text = "ReSave Sprites";
            this.reSaveSpritesToolStripMenuItem.Click += new System.EventHandler(this.reSaveSpritesToolStripMenuItem_Click);
            // 
            // saveSpritesToolStripMenuItem
            // 
            this.saveSpritesToolStripMenuItem.Name = "saveSpritesToolStripMenuItem";
            this.saveSpritesToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.saveSpritesToolStripMenuItem.Text = "Save Sprites As";
            this.saveSpritesToolStripMenuItem.Click += new System.EventHandler(this.saveSpritesToolStripMenuItem_Click);
            // 
            // savePaletteToolStripMenuItem
            // 
            this.savePaletteToolStripMenuItem.Name = "savePaletteToolStripMenuItem";
            this.savePaletteToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.savePaletteToolStripMenuItem.Text = "Save Palette";
            this.savePaletteToolStripMenuItem.Click += new System.EventHandler(this.savePaletteToolStripMenuItem_Click);
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.loadToolStripMenuItem.Text = "Load";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToClipboardToolStripMenuItem,
            this.pasteToClipToolStripMenuItem,
            this.copyPreviewToolStripMenuItem,
            this.canvasSizeToolStripMenuItem,
            this.duplicateFromToolStripMenuItem,
            this.duplicateOffsetFromToolStripMenuItem,
            this.makeTilesToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // copyToClipboardToolStripMenuItem
            // 
            this.copyToClipboardToolStripMenuItem.Name = "copyToClipboardToolStripMenuItem";
            this.copyToClipboardToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToClipboardToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.copyToClipboardToolStripMenuItem.Text = "Copy to Clipboard";
            this.copyToClipboardToolStripMenuItem.Click += new System.EventHandler(this.copyToClipboardToolStripMenuItem_Click);
            // 
            // pasteToClipToolStripMenuItem
            // 
            this.pasteToClipToolStripMenuItem.Name = "pasteToClipToolStripMenuItem";
            this.pasteToClipToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.pasteToClipToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.pasteToClipToolStripMenuItem.Text = "Paste from Clipboard";
            this.pasteToClipToolStripMenuItem.Click += new System.EventHandler(this.pasteToClipToolStripMenuItem_Click);
            // 
            // copyPreviewToolStripMenuItem
            // 
            this.copyPreviewToolStripMenuItem.Name = "copyPreviewToolStripMenuItem";
            this.copyPreviewToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift)
                        | System.Windows.Forms.Keys.C)));
            this.copyPreviewToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.copyPreviewToolStripMenuItem.Text = "Copy Preview";
            this.copyPreviewToolStripMenuItem.Click += new System.EventHandler(this.copyPreviewToolStripMenuItem_Click);
            // 
            // canvasSizeToolStripMenuItem
            // 
            this.canvasSizeToolStripMenuItem.Name = "canvasSizeToolStripMenuItem";
            this.canvasSizeToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.canvasSizeToolStripMenuItem.Text = "Canvas Size";
            this.canvasSizeToolStripMenuItem.Click += new System.EventHandler(this.canvasSizeToolStripMenuItem_Click);
            // 
            // duplicateFromToolStripMenuItem
            // 
            this.duplicateFromToolStripMenuItem.Name = "duplicateFromToolStripMenuItem";
            this.duplicateFromToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.duplicateFromToolStripMenuItem.Text = "Duplicate From";
            this.duplicateFromToolStripMenuItem.Click += new System.EventHandler(this.duplicateFromToolStripMenuItem_Click);
            // 
            // duplicateOffsetFromToolStripMenuItem
            // 
            this.duplicateOffsetFromToolStripMenuItem.Name = "duplicateOffsetFromToolStripMenuItem";
            this.duplicateOffsetFromToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.duplicateOffsetFromToolStripMenuItem.Text = "Duplicate Offset From";
            this.duplicateOffsetFromToolStripMenuItem.Click += new System.EventHandler(this.duplicateOffsetFromToolStripMenuItem_Click);
            // 
            // makeTilesToolStripMenuItem
            // 
            this.makeTilesToolStripMenuItem.Name = "makeTilesToolStripMenuItem";
            this.makeTilesToolStripMenuItem.Size = new System.Drawing.Size(216, 22);
            this.makeTilesToolStripMenuItem.Text = "Make Tiles";
            this.makeTilesToolStripMenuItem.Click += new System.EventHandler(this.makeTilesToolStripMenuItem_Click);
            // 
            // ViewToolStripMenuItem
            // 
            this.ViewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mSX16ColorToolStripMenuItem,
            this.cPC4ColorToolStripMenuItem,
            this.zX2ColorToolStripMenuItem,
            this.highVisToggleToolStripMenuItem,
            this.overlayLastFrameToolStripMenuItem,
            this.overlayNextFrameToolStripMenuItem});
            this.ViewToolStripMenuItem.Name = "ViewToolStripMenuItem";
            this.ViewToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.ViewToolStripMenuItem.Text = "View";
            // 
            // mSX16ColorToolStripMenuItem
            // 
            this.mSX16ColorToolStripMenuItem.Name = "mSX16ColorToolStripMenuItem";
            this.mSX16ColorToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.mSX16ColorToolStripMenuItem.Text = "MSX 16 Color";
            this.mSX16ColorToolStripMenuItem.Click += new System.EventHandler(this.mSX16ColorToolStripMenuItem_Click);
            // 
            // cPC4ColorToolStripMenuItem
            // 
            this.cPC4ColorToolStripMenuItem.Name = "cPC4ColorToolStripMenuItem";
            this.cPC4ColorToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.cPC4ColorToolStripMenuItem.Text = "CPC 4 color";
            this.cPC4ColorToolStripMenuItem.Click += new System.EventHandler(this.cPC4ColorToolStripMenuItem_Click);
            // 
            // zX2ColorToolStripMenuItem
            // 
            this.zX2ColorToolStripMenuItem.Name = "zX2ColorToolStripMenuItem";
            this.zX2ColorToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.zX2ColorToolStripMenuItem.Text = "ZX 2 color";
            this.zX2ColorToolStripMenuItem.Click += new System.EventHandler(this.zX2ColorToolStripMenuItem_Click);
            // 
            // highVisToggleToolStripMenuItem
            // 
            this.highVisToggleToolStripMenuItem.Name = "highVisToggleToolStripMenuItem";
            this.highVisToggleToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.highVisToggleToolStripMenuItem.Text = "HighVis Toggle";
            this.highVisToggleToolStripMenuItem.Click += new System.EventHandler(this.highVisToggleToolStripMenuItem_Click);
            // 
            // overlayLastFrameToolStripMenuItem
            // 
            this.overlayLastFrameToolStripMenuItem.Name = "overlayLastFrameToolStripMenuItem";
            this.overlayLastFrameToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.overlayLastFrameToolStripMenuItem.Text = "Overlay LastFrame";
            this.overlayLastFrameToolStripMenuItem.Click += new System.EventHandler(this.overlayLastFrameToolStripMenuItem_Click);
            // 
            // overlayNextFrameToolStripMenuItem
            // 
            this.overlayNextFrameToolStripMenuItem.Name = "overlayNextFrameToolStripMenuItem";
            this.overlayNextFrameToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.overlayNextFrameToolStripMenuItem.Text = "Overlay NextFrame";
            this.overlayNextFrameToolStripMenuItem.Click += new System.EventHandler(this.overlayNextFrameToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.transformToolStripMenuItem,
            this.colorSwapAllToolStripMenuItem,
            this.yInterlaceToolStripMenuItem,
            this.setAllAttribsToolStripMenuItem,
            this.blackBorderToolStripMenuItem,
            this.blackBorderTightToolStripMenuItem,
            this.PaletteTint});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.toolsToolStripMenuItem.Text = "Tools";
            // 
            // transformToolStripMenuItem
            // 
            this.transformToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.flipXToolStripMenuItem,
            this.flipYToolStripMenuItem,
            this.pxShiftToolStripMenuItem,
            this.pixelShiftRightToolStripMenuItem,
            this.pixelShiftUpToolStripMenuItem,
            this.pixelShiftDownToolStripMenuItem,
            this.tileShiftXToolStripMenuItem});
            this.transformToolStripMenuItem.Name = "transformToolStripMenuItem";
            this.transformToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.transformToolStripMenuItem.Text = "Transform";
            // 
            // flipXToolStripMenuItem
            // 
            this.flipXToolStripMenuItem.Name = "flipXToolStripMenuItem";
            this.flipXToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.flipXToolStripMenuItem.Text = "FlipX";
            this.flipXToolStripMenuItem.Click += new System.EventHandler(this.flipXToolStripMenuItem_Click);
            // 
            // flipYToolStripMenuItem
            // 
            this.flipYToolStripMenuItem.Name = "flipYToolStripMenuItem";
            this.flipYToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.flipYToolStripMenuItem.Text = "FlipY";
            this.flipYToolStripMenuItem.Click += new System.EventHandler(this.flipYToolStripMenuItem_Click);
            // 
            // pxShiftToolStripMenuItem
            // 
            this.pxShiftToolStripMenuItem.Name = "pxShiftToolStripMenuItem";
            this.pxShiftToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.pxShiftToolStripMenuItem.Text = "Pixel Shift Left";
            this.pxShiftToolStripMenuItem.Click += new System.EventHandler(this.pxShiftToolStripMenuItem_Click);
            // 
            // pixelShiftRightToolStripMenuItem
            // 
            this.pixelShiftRightToolStripMenuItem.Name = "pixelShiftRightToolStripMenuItem";
            this.pixelShiftRightToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.pixelShiftRightToolStripMenuItem.Text = "Pixel Shift Right";
            this.pixelShiftRightToolStripMenuItem.Click += new System.EventHandler(this.pixelShiftRightToolStripMenuItem_Click);
            // 
            // pixelShiftUpToolStripMenuItem
            // 
            this.pixelShiftUpToolStripMenuItem.Name = "pixelShiftUpToolStripMenuItem";
            this.pixelShiftUpToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.pixelShiftUpToolStripMenuItem.Text = "Pixel Shift Up";
            this.pixelShiftUpToolStripMenuItem.Click += new System.EventHandler(this.pixelShiftUpToolStripMenuItem_Click);
            // 
            // pixelShiftDownToolStripMenuItem
            // 
            this.pixelShiftDownToolStripMenuItem.Name = "pixelShiftDownToolStripMenuItem";
            this.pixelShiftDownToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.pixelShiftDownToolStripMenuItem.Text = "Pixel Shift Down";
            this.pixelShiftDownToolStripMenuItem.Click += new System.EventHandler(this.pixelShiftDownToolStripMenuItem_Click);
            // 
            // tileShiftXToolStripMenuItem
            // 
            this.tileShiftXToolStripMenuItem.Name = "tileShiftXToolStripMenuItem";
            this.tileShiftXToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.tileShiftXToolStripMenuItem.Text = "TileShiftX";
            this.tileShiftXToolStripMenuItem.Click += new System.EventHandler(this.tileShiftXToolStripMenuItem_Click);
            // 
            // colorSwapAllToolStripMenuItem
            // 
            this.colorSwapAllToolStripMenuItem.Name = "colorSwapAllToolStripMenuItem";
            this.colorSwapAllToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.colorSwapAllToolStripMenuItem.Text = "Color SwapAll";
            this.colorSwapAllToolStripMenuItem.Click += new System.EventHandler(this.colorSwapAllToolStripMenuItem_Click);
            // 
            // yInterlaceToolStripMenuItem
            // 
            this.yInterlaceToolStripMenuItem.Name = "yInterlaceToolStripMenuItem";
            this.yInterlaceToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.yInterlaceToolStripMenuItem.Text = "Interlace-Y";
            this.yInterlaceToolStripMenuItem.Click += new System.EventHandler(this.yInterlaceToolStripMenuItem_Click);
            // 
            // setAllAttribsToolStripMenuItem
            // 
            this.setAllAttribsToolStripMenuItem.Name = "setAllAttribsToolStripMenuItem";
            this.setAllAttribsToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.setAllAttribsToolStripMenuItem.Text = "SetAllAttribs";
            this.setAllAttribsToolStripMenuItem.Click += new System.EventHandler(this.setAllAttribsToolStripMenuItem_Click);
            // 
            // blackBorderToolStripMenuItem
            // 
            this.blackBorderToolStripMenuItem.Name = "blackBorderToolStripMenuItem";
            this.blackBorderToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.blackBorderToolStripMenuItem.Text = "BlackBorder";
            this.blackBorderToolStripMenuItem.Click += new System.EventHandler(this.blackBorderToolStripMenuItem_Click);
            // 
            // blackBorderTightToolStripMenuItem
            // 
            this.blackBorderTightToolStripMenuItem.Name = "blackBorderTightToolStripMenuItem";
            this.blackBorderTightToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.blackBorderTightToolStripMenuItem.Text = "BlackBorder Tight";
            this.blackBorderTightToolStripMenuItem.Click += new System.EventHandler(this.blackBorderTightToolStripMenuItem_Click);
            // 
            // PaletteTint
            // 
            this.PaletteTint.Name = "PaletteTint";
            this.PaletteTint.Size = new System.Drawing.Size(163, 22);
            this.PaletteTint.Text = "Palette Tint";
            this.PaletteTint.Click += new System.EventHandler(this.PaletteTint_Click);
            // 
            // cPCToolStripMenuItem
            // 
            this.cPCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem3,
            this.spriteCompilerToolStripMenuItem,
            this.saveASMPaletteToolStripMenuItem});
            this.cPCToolStripMenuItem.Name = "cPCToolStripMenuItem";
            this.cPCToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.cPCToolStripMenuItem.Text = "<CPC>";
            // 
            // fileToolStripMenuItem3
            // 
            this.fileToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadCPCBinaryToolStripMenuItem,
            this.saveCPCBinaryToolStripMenuItem1,
            this.loadCPCBinaryToolStripMenuItem1,
            this.saveCPCBinaryToolStripMenuItem,
            this.SaveCPCRawBmp,
            this.rLEASMToolStripMenuItem,
            this.saveCPCZigTileToolStripMenuItem});
            this.fileToolStripMenuItem3.Name = "fileToolStripMenuItem3";
            this.fileToolStripMenuItem3.Size = new System.Drawing.Size(163, 22);
            this.fileToolStripMenuItem3.Text = "File";
            // 
            // loadCPCBinaryToolStripMenuItem
            // 
            this.loadCPCBinaryToolStripMenuItem.Name = "loadCPCBinaryToolStripMenuItem";
            this.loadCPCBinaryToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.loadCPCBinaryToolStripMenuItem.Text = "Load CPC+ Binary";
            this.loadCPCBinaryToolStripMenuItem.Click += new System.EventHandler(this.loadCPCBinaryToolStripMenuItem_Click);
            // 
            // saveCPCBinaryToolStripMenuItem1
            // 
            this.saveCPCBinaryToolStripMenuItem1.Name = "saveCPCBinaryToolStripMenuItem1";
            this.saveCPCBinaryToolStripMenuItem1.Size = new System.Drawing.Size(199, 22);
            this.saveCPCBinaryToolStripMenuItem1.Text = "Save CPC+ Binary";
            this.saveCPCBinaryToolStripMenuItem1.Click += new System.EventHandler(this.saveCPCBinaryToolStripMenuItem1_Click);
            // 
            // loadCPCBinaryToolStripMenuItem1
            // 
            this.loadCPCBinaryToolStripMenuItem1.Name = "loadCPCBinaryToolStripMenuItem1";
            this.loadCPCBinaryToolStripMenuItem1.Size = new System.Drawing.Size(199, 22);
            this.loadCPCBinaryToolStripMenuItem1.Text = "Load CPC Binary";
            this.loadCPCBinaryToolStripMenuItem1.Click += new System.EventHandler(this.loadCPCBinaryToolStripMenuItem1_Click);
            // 
            // saveCPCBinaryToolStripMenuItem
            // 
            this.saveCPCBinaryToolStripMenuItem.Name = "saveCPCBinaryToolStripMenuItem";
            this.saveCPCBinaryToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.saveCPCBinaryToolStripMenuItem.Text = "Save CPC Binary Sprites";
            this.saveCPCBinaryToolStripMenuItem.Click += new System.EventHandler(this.saveCPCBinaryToolStripMenuItem_Click);
            // 
            // SaveCPCRawBmp
            // 
            this.SaveCPCRawBmp.Name = "SaveCPCRawBmp";
            this.SaveCPCRawBmp.Size = new System.Drawing.Size(199, 22);
            this.SaveCPCRawBmp.Text = "Save RAW Bitmap";
            this.SaveCPCRawBmp.Click += new System.EventHandler(this.SaveCPCRawBmp_Click);
            // 
            // rLEASMToolStripMenuItem
            // 
            this.rLEASMToolStripMenuItem.Name = "rLEASMToolStripMenuItem";
            this.rLEASMToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.rLEASMToolStripMenuItem.Text = "RLE ASM";
            this.rLEASMToolStripMenuItem.Click += new System.EventHandler(this.rLEASMToolStripMenuItem_Click);
            // 
            // saveCPCZigTileToolStripMenuItem
            // 
            this.saveCPCZigTileToolStripMenuItem.Name = "saveCPCZigTileToolStripMenuItem";
            this.saveCPCZigTileToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.saveCPCZigTileToolStripMenuItem.Text = "Save CPC ZigTile";
            this.saveCPCZigTileToolStripMenuItem.Click += new System.EventHandler(this.saveCPCZigTileToolStripMenuItem_Click);
            // 
            // spriteCompilerToolStripMenuItem
            // 
            this.spriteCompilerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addOneToolStripMenuItem});
            this.spriteCompilerToolStripMenuItem.Name = "spriteCompilerToolStripMenuItem";
            this.spriteCompilerToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.spriteCompilerToolStripMenuItem.Text = "SpriteCompiler";
            // 
            // addOneToolStripMenuItem
            // 
            this.addOneToolStripMenuItem.Name = "addOneToolStripMenuItem";
            this.addOneToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.addOneToolStripMenuItem.Text = "AddOne";
            this.addOneToolStripMenuItem.Click += new System.EventHandler(this.addOneToolStripMenuItem_Click);
            // 
            // saveASMPaletteToolStripMenuItem
            // 
            this.saveASMPaletteToolStripMenuItem.Name = "saveASMPaletteToolStripMenuItem";
            this.saveASMPaletteToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.saveASMPaletteToolStripMenuItem.Text = "Save ASM Palette";
            this.saveASMPaletteToolStripMenuItem.Click += new System.EventHandler(this.saveASMPaletteToolStripMenuItem_Click);
            // 
            // mSXToolStripMenuItem
            // 
            this.mSXToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem1});
            this.mSXToolStripMenuItem.Name = "mSXToolStripMenuItem";
            this.mSXToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.mSXToolStripMenuItem.Text = "<MSX>";
            // 
            // fileToolStripMenuItem1
            // 
            this.fileToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveMSXASMPaletteToolStripMenuItem,
            this.saveMSXBinaryToolStripMenuItem,
            this.bMPToolStripMenuItem,
            this.rLEToolStripMenuItem,
            this.saveRAWBitmapToolStripMenuItem3});
            this.fileToolStripMenuItem1.Name = "fileToolStripMenuItem1";
            this.fileToolStripMenuItem1.Size = new System.Drawing.Size(89, 22);
            this.fileToolStripMenuItem1.Text = "File";
            // 
            // saveMSXASMPaletteToolStripMenuItem
            // 
            this.saveMSXASMPaletteToolStripMenuItem.Name = "saveMSXASMPaletteToolStripMenuItem";
            this.saveMSXASMPaletteToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.saveMSXASMPaletteToolStripMenuItem.Text = "Save MSX ASM Palette";
            this.saveMSXASMPaletteToolStripMenuItem.Click += new System.EventHandler(this.saveMSXASMPaletteToolStripMenuItem_Click);
            // 
            // saveMSXBinaryToolStripMenuItem
            // 
            this.saveMSXBinaryToolStripMenuItem.Name = "saveMSXBinaryToolStripMenuItem";
            this.saveMSXBinaryToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.saveMSXBinaryToolStripMenuItem.Text = "Save MSX Binary Sprites";
            this.saveMSXBinaryToolStripMenuItem.Click += new System.EventHandler(this.saveMSXBinaryToolStripMenuItem_Click);
            // 
            // bMPToolStripMenuItem
            // 
            this.bMPToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveMSXBitmapToolStripMenuItem1,
            this.saveMSXBitmapWithPaletteToolStripMenuItem1,
            this.saveMSXBitmapSpritesToolStripMenuItem});
            this.bMPToolStripMenuItem.Name = "bMPToolStripMenuItem";
            this.bMPToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.bMPToolStripMenuItem.Text = "BMP";
            // 
            // saveMSXBitmapToolStripMenuItem1
            // 
            this.saveMSXBitmapToolStripMenuItem1.Name = "saveMSXBitmapToolStripMenuItem1";
            this.saveMSXBitmapToolStripMenuItem1.Size = new System.Drawing.Size(228, 22);
            this.saveMSXBitmapToolStripMenuItem1.Text = "save MSX bitmap";
            this.saveMSXBitmapToolStripMenuItem1.Click += new System.EventHandler(this.saveMSXBitmapToolStripMenuItem1_Click);
            // 
            // saveMSXBitmapWithPaletteToolStripMenuItem1
            // 
            this.saveMSXBitmapWithPaletteToolStripMenuItem1.Name = "saveMSXBitmapWithPaletteToolStripMenuItem1";
            this.saveMSXBitmapWithPaletteToolStripMenuItem1.Size = new System.Drawing.Size(228, 22);
            this.saveMSXBitmapWithPaletteToolStripMenuItem1.Text = "Save MSX Bitmap With Palette";
            this.saveMSXBitmapWithPaletteToolStripMenuItem1.Click += new System.EventHandler(this.saveMSXBitmapWithPaletteToolStripMenuItem1_Click);
            // 
            // saveMSXBitmapSpritesToolStripMenuItem
            // 
            this.saveMSXBitmapSpritesToolStripMenuItem.Name = "saveMSXBitmapSpritesToolStripMenuItem";
            this.saveMSXBitmapSpritesToolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.saveMSXBitmapSpritesToolStripMenuItem.Text = "save MSX Bitmap Sprites";
            this.saveMSXBitmapSpritesToolStripMenuItem.Click += new System.EventHandler(this.saveMSXBitmapSpritesToolStripMenuItem_Click);
            // 
            // rLEToolStripMenuItem
            // 
            this.rLEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.buildRLEASMToolStripMenuItem,
            this.saveMSXRLEToolStripMenuItem,
            this.saveMSXRLEPaletteToolStripMenuItem,
            this.saveMSXRLESpritesToolStripMenuItem});
            this.rLEToolStripMenuItem.Name = "rLEToolStripMenuItem";
            this.rLEToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.rLEToolStripMenuItem.Text = "RLE";
            // 
            // buildRLEASMToolStripMenuItem
            // 
            this.buildRLEASMToolStripMenuItem.Name = "buildRLEASMToolStripMenuItem";
            this.buildRLEASMToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.buildRLEASMToolStripMenuItem.Text = "Build RLE ASM";
            this.buildRLEASMToolStripMenuItem.Click += new System.EventHandler(this.buildRLEASMToolStripMenuItem_Click);
            // 
            // saveMSXRLEToolStripMenuItem
            // 
            this.saveMSXRLEToolStripMenuItem.Name = "saveMSXRLEToolStripMenuItem";
            this.saveMSXRLEToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.saveMSXRLEToolStripMenuItem.Text = "Save MSX RLE";
            this.saveMSXRLEToolStripMenuItem.Click += new System.EventHandler(this.saveMSXRLEToolStripMenuItem_Click);
            // 
            // saveMSXRLEPaletteToolStripMenuItem
            // 
            this.saveMSXRLEPaletteToolStripMenuItem.Name = "saveMSXRLEPaletteToolStripMenuItem";
            this.saveMSXRLEPaletteToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.saveMSXRLEPaletteToolStripMenuItem.Text = "Save MSX RLE Palette";
            this.saveMSXRLEPaletteToolStripMenuItem.Click += new System.EventHandler(this.saveMSXRLEPaletteToolStripMenuItem_Click);
            // 
            // saveMSXRLESpritesToolStripMenuItem
            // 
            this.saveMSXRLESpritesToolStripMenuItem.Name = "saveMSXRLESpritesToolStripMenuItem";
            this.saveMSXRLESpritesToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.saveMSXRLESpritesToolStripMenuItem.Text = "Save MSX RLE Sprites";
            this.saveMSXRLESpritesToolStripMenuItem.Click += new System.EventHandler(this.saveMSXRLESpritesToolStripMenuItem_Click);
            // 
            // saveRAWBitmapToolStripMenuItem3
            // 
            this.saveRAWBitmapToolStripMenuItem3.Name = "saveRAWBitmapToolStripMenuItem3";
            this.saveRAWBitmapToolStripMenuItem3.Size = new System.Drawing.Size(199, 22);
            this.saveRAWBitmapToolStripMenuItem3.Text = "Save RAW Bitmap";
            this.saveRAWBitmapToolStripMenuItem3.Click += new System.EventHandler(this.saveRAWBitmapToolStripMenuItem3_Click);
            // 
            // zXToolStripMenuItem
            // 
            this.zXToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolsToolStripMenuItem1,
            this.spriteCompilerToolStripMenuItem2,
            this.pasteZXToolStripMenuItem});
            this.zXToolStripMenuItem.Name = "zXToolStripMenuItem";
            this.zXToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.zXToolStripMenuItem.Text = "<ZX>";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.loadSpectrumScreenToolStripMenuItem,
            this.saveSpectrumBinaryToolStripMenuItem1,
            this.saveSpectrumTilesToolStripMenuItem,
            this.saveSpectrumFontToolStripMenuItem,
            this.saveSpectrumScreenToolStripMenuItem,
            this.saveRawBitmapToolStripMenuItem4,
            this.rLEASMToolStripMenuItem1,
            this.rLEASMCOLORToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loadSpectrumScreenToolStripMenuItem
            // 
            this.loadSpectrumScreenToolStripMenuItem.Name = "loadSpectrumScreenToolStripMenuItem";
            this.loadSpectrumScreenToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.loadSpectrumScreenToolStripMenuItem.Text = "Load Spectrum Screen";
            this.loadSpectrumScreenToolStripMenuItem.Click += new System.EventHandler(this.loadSpectrumScreenToolStripMenuItem_Click);
            // 
            // saveSpectrumBinaryToolStripMenuItem1
            // 
            this.saveSpectrumBinaryToolStripMenuItem1.Name = "saveSpectrumBinaryToolStripMenuItem1";
            this.saveSpectrumBinaryToolStripMenuItem1.Size = new System.Drawing.Size(224, 22);
            this.saveSpectrumBinaryToolStripMenuItem1.Text = "Save Spectrum Binary Sprites";
            this.saveSpectrumBinaryToolStripMenuItem1.Click += new System.EventHandler(this.saveSpectrumBinaryToolStripMenuItem1_Click);
            // 
            // saveSpectrumTilesToolStripMenuItem
            // 
            this.saveSpectrumTilesToolStripMenuItem.Name = "saveSpectrumTilesToolStripMenuItem";
            this.saveSpectrumTilesToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.saveSpectrumTilesToolStripMenuItem.Text = "Save Spectrum Tiles";
            this.saveSpectrumTilesToolStripMenuItem.Click += new System.EventHandler(this.saveSpectrumTilesToolStripMenuItem_Click);
            // 
            // saveSpectrumFontToolStripMenuItem
            // 
            this.saveSpectrumFontToolStripMenuItem.Name = "saveSpectrumFontToolStripMenuItem";
            this.saveSpectrumFontToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.saveSpectrumFontToolStripMenuItem.Text = "Save 2 Bit Spectrum Font";
            this.saveSpectrumFontToolStripMenuItem.Click += new System.EventHandler(this.saveSpectrumFontToolStripMenuItem_Click);
            // 
            // saveSpectrumScreenToolStripMenuItem
            // 
            this.saveSpectrumScreenToolStripMenuItem.Name = "saveSpectrumScreenToolStripMenuItem";
            this.saveSpectrumScreenToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.saveSpectrumScreenToolStripMenuItem.Text = "Save Spectrum Screen";
            this.saveSpectrumScreenToolStripMenuItem.Click += new System.EventHandler(this.saveSpectrumScreenToolStripMenuItem_Click);
            // 
            // saveRawBitmapToolStripMenuItem4
            // 
            this.saveRawBitmapToolStripMenuItem4.Name = "saveRawBitmapToolStripMenuItem4";
            this.saveRawBitmapToolStripMenuItem4.Size = new System.Drawing.Size(224, 22);
            this.saveRawBitmapToolStripMenuItem4.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem4.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem4_Click);
            // 
            // rLEASMToolStripMenuItem1
            // 
            this.rLEASMToolStripMenuItem1.Name = "rLEASMToolStripMenuItem1";
            this.rLEASMToolStripMenuItem1.Size = new System.Drawing.Size(224, 22);
            this.rLEASMToolStripMenuItem1.Text = "RLE ASM";
            this.rLEASMToolStripMenuItem1.Visible = false;
            // 
            // rLEASMCOLORToolStripMenuItem
            // 
            this.rLEASMCOLORToolStripMenuItem.Name = "rLEASMCOLORToolStripMenuItem";
            this.rLEASMCOLORToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.rLEASMCOLORToolStripMenuItem.Text = "RLE ASM COLOR";
            this.rLEASMCOLORToolStripMenuItem.Click += new System.EventHandler(this.rLEASMCOLORToolStripMenuItem_Click);
            // 
            // toolsToolStripMenuItem1
            // 
            this.toolsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fourColor2ToolStripMenuItem,
            this.invertZXToolStripMenuItem1,
            this.halfSizeFontToolStripMenuItem});
            this.toolsToolStripMenuItem1.Name = "toolsToolStripMenuItem1";
            this.toolsToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.toolsToolStripMenuItem1.Text = "Tools";
            // 
            // fourColor2ToolStripMenuItem
            // 
            this.fourColor2ToolStripMenuItem.Name = "fourColor2ToolStripMenuItem";
            this.fourColor2ToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.fourColor2ToolStripMenuItem.Text = "4 Color->2 ";
            this.fourColor2ToolStripMenuItem.Click += new System.EventHandler(this.fourColor2ToolStripMenuItem_Click);
            // 
            // invertZXToolStripMenuItem1
            // 
            this.invertZXToolStripMenuItem1.Name = "invertZXToolStripMenuItem1";
            this.invertZXToolStripMenuItem1.Size = new System.Drawing.Size(135, 22);
            this.invertZXToolStripMenuItem1.Text = "Invert ZX";
            this.invertZXToolStripMenuItem1.Click += new System.EventHandler(this.invertZXToolStripMenuItem1_Click);
            // 
            // halfSizeFontToolStripMenuItem
            // 
            this.halfSizeFontToolStripMenuItem.Name = "halfSizeFontToolStripMenuItem";
            this.halfSizeFontToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.halfSizeFontToolStripMenuItem.Text = "HalfSizeFont";
            this.halfSizeFontToolStripMenuItem.Click += new System.EventHandler(this.halfSizeFontToolStripMenuItem_Click);
            // 
            // spriteCompilerToolStripMenuItem2
            // 
            this.spriteCompilerToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addOneToolStripMenuItem2});
            this.spriteCompilerToolStripMenuItem2.Name = "spriteCompilerToolStripMenuItem2";
            this.spriteCompilerToolStripMenuItem2.Size = new System.Drawing.Size(145, 22);
            this.spriteCompilerToolStripMenuItem2.Text = "SpriteCompiler";
            // 
            // addOneToolStripMenuItem2
            // 
            this.addOneToolStripMenuItem2.Name = "addOneToolStripMenuItem2";
            this.addOneToolStripMenuItem2.Size = new System.Drawing.Size(110, 22);
            this.addOneToolStripMenuItem2.Text = "AddOne";
            this.addOneToolStripMenuItem2.Click += new System.EventHandler(this.addOneToolStripMenuItem2_Click);
            // 
            // pasteZXToolStripMenuItem
            // 
            this.pasteZXToolStripMenuItem.Name = "pasteZXToolStripMenuItem";
            this.pasteZXToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.pasteZXToolStripMenuItem.Text = "Paste ZX";
            this.pasteZXToolStripMenuItem.Click += new System.EventHandler(this.pasteZXToolStripMenuItem_Click);
            // 
            // tIToolStripMenuItem
            // 
            this.tIToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filrToolStripMenuItem});
            this.tIToolStripMenuItem.Name = "tIToolStripMenuItem";
            this.tIToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.tIToolStripMenuItem.Text = "<TI>";
            // 
            // filrToolStripMenuItem
            // 
            this.filrToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem1});
            this.filrToolStripMenuItem.Name = "filrToolStripMenuItem";
            this.filrToolStripMenuItem.Size = new System.Drawing.Size(89, 22);
            this.filrToolStripMenuItem.Text = "File";
            // 
            // saveRawBitmapToolStripMenuItem1
            // 
            this.saveRawBitmapToolStripMenuItem1.Name = "saveRawBitmapToolStripMenuItem1";
            this.saveRawBitmapToolStripMenuItem1.Size = new System.Drawing.Size(161, 22);
            this.saveRawBitmapToolStripMenuItem1.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem1.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem1_Click);
            // 
            // sAMToolStripMenuItem
            // 
            this.sAMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem5});
            this.sAMToolStripMenuItem.Name = "sAMToolStripMenuItem";
            this.sAMToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.sAMToolStripMenuItem.Text = "<SAM>";
            // 
            // fileToolStripMenuItem5
            // 
            this.fileToolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem2,
            this.saveRLEToolStripMenuItem});
            this.fileToolStripMenuItem5.Name = "fileToolStripMenuItem5";
            this.fileToolStripMenuItem5.Size = new System.Drawing.Size(152, 22);
            this.fileToolStripMenuItem5.Text = "File";
            // 
            // saveRawBitmapToolStripMenuItem2
            // 
            this.saveRawBitmapToolStripMenuItem2.Name = "saveRawBitmapToolStripMenuItem2";
            this.saveRawBitmapToolStripMenuItem2.Size = new System.Drawing.Size(161, 22);
            this.saveRawBitmapToolStripMenuItem2.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem2.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem2_Click);
            // 
            // saveRLEToolStripMenuItem
            // 
            this.saveRLEToolStripMenuItem.Name = "saveRLEToolStripMenuItem";
            this.saveRLEToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.saveRLEToolStripMenuItem.Text = "Save RLE ASM";
            this.saveRLEToolStripMenuItem.Click += new System.EventHandler(this.saveRLEToolStripMenuItem_Click);
            // 
            // eNTToolStripMenuItem
            // 
            this.eNTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem4});
            this.eNTToolStripMenuItem.Name = "eNTToolStripMenuItem";
            this.eNTToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.eNTToolStripMenuItem.Text = "<ENT>";
            // 
            // fileToolStripMenuItem4
            // 
            this.fileToolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRAWBitmapToolStripMenuItem});
            this.fileToolStripMenuItem4.Name = "fileToolStripMenuItem4";
            this.fileToolStripMenuItem4.Size = new System.Drawing.Size(89, 22);
            this.fileToolStripMenuItem4.Text = "File";
            // 
            // saveRAWBitmapToolStripMenuItem
            // 
            this.saveRAWBitmapToolStripMenuItem.Name = "saveRAWBitmapToolStripMenuItem";
            this.saveRAWBitmapToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.saveRAWBitmapToolStripMenuItem.Text = "Save RAW Bitmap";
            this.saveRAWBitmapToolStripMenuItem.Click += new System.EventHandler(this.saveRAWBitmapToolStripMenuItem_Click);
            // 
            // sMSToolStripMenuItem
            // 
            this.sMSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem6});
            this.sMSToolStripMenuItem.Name = "sMSToolStripMenuItem";
            this.sMSToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.sMSToolStripMenuItem.Text = "<SMS>";
            // 
            // fileToolStripMenuItem6
            // 
            this.fileToolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem5});
            this.fileToolStripMenuItem6.Name = "fileToolStripMenuItem6";
            this.fileToolStripMenuItem6.Size = new System.Drawing.Size(89, 22);
            this.fileToolStripMenuItem6.Text = "File";
            // 
            // saveRawBitmapToolStripMenuItem5
            // 
            this.saveRawBitmapToolStripMenuItem5.Name = "saveRawBitmapToolStripMenuItem5";
            this.saveRawBitmapToolStripMenuItem5.Size = new System.Drawing.Size(161, 22);
            this.saveRawBitmapToolStripMenuItem5.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem5.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem5_Click);
            // 
            // gBToolStripMenuItem
            // 
            this.gBToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem7});
            this.gBToolStripMenuItem.Name = "gBToolStripMenuItem";
            this.gBToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.gBToolStripMenuItem.Text = "<GB>";
            // 
            // fileToolStripMenuItem7
            // 
            this.fileToolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveRawBitmapToolStripMenuItem6});
            this.fileToolStripMenuItem7.Name = "fileToolStripMenuItem7";
            this.fileToolStripMenuItem7.Size = new System.Drawing.Size(89, 22);
            this.fileToolStripMenuItem7.Text = "File";
            // 
            // saveRawBitmapToolStripMenuItem6
            // 
            this.saveRawBitmapToolStripMenuItem6.Name = "saveRawBitmapToolStripMenuItem6";
            this.saveRawBitmapToolStripMenuItem6.Size = new System.Drawing.Size(161, 22);
            this.saveRawBitmapToolStripMenuItem6.Text = "Save Raw Bitmap";
            this.saveRawBitmapToolStripMenuItem6.Click += new System.EventHandler(this.saveRawBitmapToolStripMenuItem6_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 637);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "AkuSprite Editor";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.picPreview)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkzoom)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabEditor.ResumeLayout(false);
            this.tabEditor.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.grpSpriteSize.ResumeLayout(false);
            this.grpSpriteSize.PerformLayout();
            this.GrpFrameOverlay.ResumeLayout(false);
            this.GrpFrameOverlay.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox picPreview;
        private System.Windows.Forms.TrackBar trkzoom;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabEditor;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoGuideNone;
        private System.Windows.Forms.RadioButton rdoGuide4_8_24;
        private System.Windows.Forms.RadioButton rdoGuide4_8_32;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ListBox lstSprites;
        private System.Windows.Forms.Button btnSetPal;
        private System.Windows.Forms.Label lblSpriteInfo;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rdoDisplaySpeccy;
        private System.Windows.Forms.RadioButton rdoDisplayCPC;
        private System.Windows.Forms.RadioButton rdoDisplayMSX;
        private System.Windows.Forms.Button btnZXpaint;
        private System.Windows.Forms.CheckBox chkHasDosHeader;
        private System.Windows.Forms.Button btnChecker;
        private System.Windows.Forms.Button btnColorSwap;
        private System.Windows.Forms.Timer tmrBackup;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.Button btnRedo;
        private System.Windows.Forms.Button btnNextSprite;
        private System.Windows.Forms.Button btnLastSprite;
        private System.Windows.Forms.TextBox txtSpriteDataOffSet;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMaxSpritesByOffset;
        private System.Windows.Forms.Label lblBackupTaken;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cPCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mSXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadSpectrumScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSpectrumBinaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveMSXASMPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXBinaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem pasteZXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem canvasSizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem loadCPCBinaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadCPCBinaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveCPCBinaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSpritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem savePaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToClipboardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToClipToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fourColor2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem invertZXToolStripMenuItem1;
        private System.Windows.Forms.CheckBox chkStrongGrid;
        private System.Windows.Forms.ToolStripMenuItem saveSpectrumScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rLEASMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rLEASMToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem rLEASMCOLORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bMPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXBitmapToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveMSXBitmapWithPaletteToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saveMSXBitmapSpritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rLEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buildRLEASMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXRLEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spriteCompilerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addOneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spriteCompilerToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem addOneToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem duplicateFromToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transformToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem flipXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem flipYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ViewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mSX16ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cPC4ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zX2ColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem highVisToggleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reSaveSpritesToolStripMenuItem;
        private System.Windows.Forms.Button btnNextBank;
        private System.Windows.Forms.Button btnLastBank;
        private System.Windows.Forms.ToolStripMenuItem duplicateOffsetFromToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXRLEPaletteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveMSXRLESpritesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colorSwapAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yInterlaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setAllAttribsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveSpectrumTilesToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSpriteSettings;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox chkAligned;
        private System.Windows.Forms.CheckBox chkFixedSize;
        private System.Windows.Forms.ToolStripMenuItem pxShiftToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blackBorderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pixelShiftRightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pixelShiftDownToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pixelShiftUpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveASMPaletteToolStripMenuItem;
        private System.Windows.Forms.GroupBox GrpFrameOverlay;
        private System.Windows.Forms.RadioButton rdoFrameNext;
        private System.Windows.Forms.RadioButton rdoFrameNone;
        private System.Windows.Forms.RadioButton rdoFrameLast;
        private System.Windows.Forms.ToolStripMenuItem overlayLastFrameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem overlayNextFrameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem makeTilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileShiftXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blackBorderTightToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PaletteTint;
        private System.Windows.Forms.ToolStripMenuItem saveSpectrumFontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem halfSizeFontToolStripMenuItem;
        private System.Windows.Forms.CheckBox ChkBackgroundTestDots;
        private System.Windows.Forms.ToolStripMenuItem saveCPCBinaryToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tIToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sAMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eNTToolStripMenuItem;
        private System.Windows.Forms.GroupBox grpSpriteSize;
        private System.Windows.Forms.RadioButton rdospr512;
        private System.Windows.Forms.RadioButton rdospr256;
        private System.Windows.Forms.ToolStripMenuItem SaveCPCRawBmp;
        private System.Windows.Forms.RadioButton rdoDisplayCPC0;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem saveRAWBitmapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem filrToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem saveRAWBitmapToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem saveCPCZigTileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sMSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem gBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem saveRawBitmapToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem saveRLEToolStripMenuItem;
    }
}

